/**
 * StatTester finds loads an Array of int
 * and finds the sum, mean, median, and mode.
 * 
 * @Sophia Raab 
 * @906
 */

// imports go here
import java.util.Arrays;
public class StatTester {
    int[] nums = new int[100];
    public void loadArray() {
        for( int i = 0; i < nums.length; i++) {
            nums[i] = (int) (Math.random()*10 + 1);
        }
    }
    
     public void printArray() {
        for( int i = 0; i < nums.length; i++) {
            //print
            System.out.print(nums[i] + " ");
            // after 10 numbers, print a newline
            if ((i + 1) % 10 == 0 ) {
                System.out.println();
            }
        }
        System.out.println();
    }
    
     public int getSum() {
        int sum = 0;
        for( int i = 0; i < nums.length; i++) {
            sum = sum + nums[i];
        }
        return sum;
    }
    
    public double getMean() {
        double mean = 0;
        mean = (double) getSum() / nums.length;
        return mean;
    }
    
    public double getMedian() {
        double median;
        Arrays.sort(nums);
        median = ( nums[49] + nums[50] ) / (double) 2;
        return median;
    }
    
    public int[] getMode() {
        int[] mode;
        mode = new int[10];
        int[] counts;
        counts = new int[11];
        for (int i = 0; i< counts.length; i++){
            counts[i] = 0;
        }
        // count number of each number in original Array
        for (int j = 0; j< nums.length; j++) {
            counts[nums[j]]++; // .... cont.
        }
        return mode;
    }
}