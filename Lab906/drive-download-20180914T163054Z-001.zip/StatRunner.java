/**
 * Lab 906::Find Mean Median and Mode
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StatRunner{
    
    
    public static void main(){
        StatTester st = new StatTester();
    }
}